# -*- coding: utf-8 -*-
"""
Created on Sat Mar 16 14:35:24 2019

@author: Administrator
"""

import os
import codecs
import DST
# you can set your own output directory path
DEFAULT_OUT_DIR = "E:/zdd"
from DST.domain_thesaurus.DomainThesaurus import DomainThesaurus
from DST.datasets.DownloadData import DownloadData


# First, you should get clean domain corpus and  general vocabulary. This may takes a long time.
# We already provide clean domain corpus and general vocabulary, so you can download and use them.

download_data = DownloadData()
# download the domain corpus
download_data.download_data(os.path.join(DEFAULT_OUT_DIR, "eng_corpus.zip"), download_file_name="eng_corpus",
                            overwrite=False)
# download general vocab
download_data.download_data(os.path.join(DEFAULT_OUT_DIR, "general_vocab.zip"), download_file_name="general_vocab",
                            overwrite=False)



# start to extract domain thesaurus
# for different datasets,  you should set different parameters
# In this example, we use default parameters
# The "cleanEng.txt" and "general_vocab.json" are the files you download
dst = DomainThesaurus(domain_specific_corpus_path=os.path.join(DEFAULT_OUT_DIR, "cleanEng.txt"),
                      general_vocab_path=os.path.join(DEFAULT_OUT_DIR, "general_vocab.json"),
                      outputDir=DEFAULT_OUT_DIR)
eng_domain_thesaurus = dst.extract()